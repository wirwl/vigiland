export const menuItems = [
    {
        text: 'О проекте',
        link: '/about'
    },
    {
        text: 'Токеномика и NFT',
        link: '/tokenomika-nft'
    },
    {
        text: 'Roadmap',
        link: '/roadmap'
    },
    {
        text: 'Документы',
        link: '/documents'
    }
];